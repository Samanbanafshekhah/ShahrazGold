<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Enums\PricingMode;
use App\Events\PriceUpdated;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\PriceStepRequest;
use App\Http\Requests\Admin\ProductRequest;
use App\Http\Requests\Admin\TradeAvailabilityRequest;
use App\Http\Resources\ProductResource;
use App\Models\MarketPriceSource;
use App\Models\Product;
use App\Services\AuditService;
use App\Services\Pricing\PriceFormulaRegistry;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class ProductController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $q = Product::with(['category', 'currentPrice']);
        $q->when($request->filled('search'), fn ($x) => $x->where(fn ($s) => $s->whereLike('name', '%'.$request->search.'%')->orWhereLike('symbol', '%'.$request->search.'%')))
            ->when($request->filled('category_id'), fn ($x) => $x->where('product_category_id', $request->category_id))->when($request->has('is_active'), fn ($x) => $x->where('is_active', $request->boolean('is_active')))
            ->when($request->has('is_buyable'), fn ($x) => $x->where('is_buyable', $request->boolean('is_buyable')))->when($request->has('is_sellable'), fn ($x) => $x->where('is_sellable', $request->boolean('is_sellable')))
            ->when($request->filled('pricing_mode'), fn ($x) => $x->where('pricing_mode', $request->pricing_mode))
            ->orderBy('display_order')->orderBy('id');

        return $this->paginated($q->paginate(min($request->integer('per_page', 15), 100)), fn ($p) => (new ProductResource($p))->resolve($request));
    }

    public function reorder(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'product_ids' => ['required', 'array', 'min:1'],
            'product_ids.*' => [
                'required',
                'integer',
                'distinct:strict',
                Rule::exists('products', 'id')->whereNull('deleted_at'),
            ],
        ]);
        $productIds = array_map('intval', $validated['product_ids']);
        $allProductIds = Product::query()->pluck('id')->map(fn ($id) => (int) $id)->all();

        if (count($productIds) !== count($allProductIds)
            || array_diff($productIds, $allProductIds)
            || array_diff($allProductIds, $productIds)) {
            return response()->json([
                'message' => 'The complete product order is required.',
                'errors' => ['product_ids' => ['The complete product order is required.']],
            ], 422);
        }

        DB::transaction(function () use ($productIds): void {
            Product::query()->lockForUpdate()->get(['id']);

            foreach ($productIds as $index => $productId) {
                Product::query()->whereKey($productId)->update(['display_order' => $index + 1]);
            }
        }, 3);

        return $this->success(['product_ids' => $productIds], 'Product order updated.');
    }

    public function store(ProductRequest $request, PriceFormulaRegistry $registry, AuditService $audit): JsonResponse
    {
        $data = $this->payload($request);
        $this->assertFormulaSource($data, $registry);
        $p = Product::create($data);
        $audit->record('product.created', $p, null, $p->toArray());

        return $this->success((new ProductResource($p->load(['category', 'currentPrice'])))->resolve($request), 'Product created.', 201);
    }

    public function show(Request $request, Product $product): JsonResponse
    {
        return $this->success((new ProductResource($product->load(['category', 'currentPrice'])))->resolve($request));
    }

    public function update(ProductRequest $request, Product $product, PriceFormulaRegistry $registry, AuditService $audit): JsonResponse
    {
        $data = $this->payload($request);
        $this->assertFormulaSource($data, $registry);
        $old = $product->toArray();
        $product->update($data);
        $pricePresentationChanged = $product->wasChanged('sell_price_difference_rial');
        if ($pricePresentationChanged) {
            $product->increment('price_version');
        }
        $audit->record('product.updated', $product, $old, $product->fresh()->toArray());

        if ($pricePresentationChanged && ($currentPrice = $product->currentPrice()->first())) {
            PriceUpdated::dispatch($currentPrice);
        }

        return $this->success((new ProductResource($product->fresh()->load(['category', 'currentPrice'])))->resolve($request), 'Product updated.');
    }

    public function updatePriceStep(PriceStepRequest $request, Product $product, AuditService $audit): JsonResponse
    {
        $old = $product->toArray();
        $product->update($request->validated());
        $audit->record('product.price_step_updated', $product, $old, $product->fresh()->toArray());

        return $this->success(
            (new ProductResource($product->fresh()->load(['category', 'currentPrice'])))->resolve($request),
            'Product price step updated.'
        );
    }

    public function updateTradeAvailability(TradeAvailabilityRequest $request, Product $product, AuditService $audit): JsonResponse
    {
        $old = $product->only(['buy_disabled', 'sell_disabled']);
        $product->fill($request->validated());

        if ($product->isDirty(['buy_disabled', 'sell_disabled'])) {
            $product->price_version = (int) $product->price_version + 1;
            $product->save();
            $audit->record('product.trade_availability_updated', $product, $old, $product->fresh()->only(['buy_disabled', 'sell_disabled']));

            if ($currentPrice = $product->currentPrice()->first()) {
                PriceUpdated::dispatch($currentPrice);
            }
        }

        return $this->success(
            (new ProductResource($product->fresh()->load(['category', 'currentPrice'])))->resolve($request),
            'Trade availability updated.',
        );
    }

    public function destroy(Product $product): JsonResponse
    {
        $product->delete();

        return $this->success(null, 'Product deleted.');
    }

    private function payload(ProductRequest $request): array
    {
        $d = $request->safe()->except('image');
        $d['slug'] = $d['slug'] ?? Str::slug($d['name']);
        if ($d['pricing_mode'] === PricingMode::Manual->value) {
            $d['price_source_id'] = null;
            $d['pricing_formula_key'] = null;
        }if ($request->hasFile('image')) {
            $d['image_path'] = $request->file('image')->store('products', 'public');
        }

        return $d;
    }

    private function assertFormulaSource(array $data, PriceFormulaRegistry $registry): void
    {
        if ($data['pricing_mode'] !== PricingMode::Derived->value) {
            return;
        }$formula = $registry->get($data['pricing_formula_key']);
        $source = MarketPriceSource::findOrFail($data['price_source_id']);
        abort_unless($formula->sourceCode() === $source->code, 409, 'Pricing formula is incompatible with the selected source.');
    }
}
